<?php
class Invoice_Model_Product extends Core_Model_Item_Abstract{

}
?>