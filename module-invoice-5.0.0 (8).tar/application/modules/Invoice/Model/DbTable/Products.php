<?php
class Invoice_Model_DbTable_Products extends Core_Model_Item_DbTable_Abstract{

}
?>

 